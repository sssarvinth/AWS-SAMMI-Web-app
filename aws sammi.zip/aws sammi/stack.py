# -*- coding: utf-8 -*-
"""
Created on Mon Jun 29 19:56:22 2020

@author: Arvinth
"""

from flask import Flask, render_template,request
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)

ENV = 'prod'

if ENV == 'dev':
    app.debug = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost/awsfeedback'
else:
    app.debug = False
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgres://egndkyjieymiuu:6bb9180225be3ebf7e5e1692e0c7fbee81fd7eeb8682ba26bb254b0b10c09950@ec2-52-207-124-89.compute-1.amazonaws.com:5432/d2lnhqiah1sfhc'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


class Feedback(db.Model):
    __tablename__ = 'awsscoretable'
    id = db.Column(db.Integer, primary_key=True)
    date=db.Column(db.Text())
    time=db.Column(db.Text())
    
    Verifier_ID = db.Column(db.String(20))
    Audio_Length = db.Column(db.Text())
    Buffer_Space = db.Column(db.Integer)
    Segment_Duplication = db.Column(db.Integer)
    Segment_Missed = db.Column(db.Integer)
    Speaker_Error = db.Column(db.Integer)
    Noise_Labelling = db.Column(db.Integer)
    I_Capitalization = db.Column(db.Integer)
    ProperNoun_Capitalization = db.Column(db.Integer)
    Simple_Word_Error = db.Column(db.Integer)
    Referencing_Error = db.Column(db.Integer)
    Punctuation_Error = db.Column(db.Integer) 
    Comments = db.Column(db.Text())

    def __init__(self,date,time,Verifier_ID,Audio_Length,Buffer_Space,Segment_Duplication,Segment_Missed,Speaker_Error,Noise_Labelling,I_Capitalization,ProperNoun_Capitalization,Simple_Word_Error, Referencing_Error,Punctuation_Error,Comments):
        self.date=date
        self.time=time
        
        self.Verifier_ID = Verifier_ID
        self.Audio_Length = Audio_Length
        self.Buffer_Space = Buffer_Space
        self.Segment_Duplication = Segment_Duplication       
        self.Segment_Missed = Segment_Missed
        self.Speaker_Error = Speaker_Error
        self.Noise_Labelling = Noise_Labelling
        self.I_Capitalization = I_Capitalization
        self.ProperNoun_Capitalization = ProperNoun_Capitalization
        self.Simple_Word_Error = Simple_Word_Error
        self.Referencing_Error = Referencing_Error
        self.Punctuation_Error = Punctuation_Error
        self.Comments = Comments


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/submit', methods=['POST'])
def submit():
      
    if request.method == 'POST':
        date= request.form['date']
        time= request.form['time']
    
        Verifier_ID = request.form['Verifier_ID']
        Audio_Length = request.form['Audio_Length']
        Buffer_Space = request.form['Buffer_Space']
        Segment_Duplication = request.form['Segment_Duplication']
        Segment_Missed = request.form['Segment_Missed']
        Speaker_Error = request.form['Speaker_Error']
        Noise_Labelling = request.form['Noise_Labelling']
        I_Capitalization = request.form['I_Capitalization']
        ProperNoun_Capitalization = request.form['ProperNoun_Capitalization']
        Simple_Word_Error = request.form['Simple_Word_Error']
        Referencing_Error = request.form['Referencing_Error']
        Punctuation_Error = request.form['Punctuation_Error']
        Comments = request.form['Comments']
        # print(user_id,segmentation_errorlist)
        
        if date ==''  or Verifier_ID == '' or Audio_Length =='' or Buffer_Space == '' or Segment_Duplication == '' or Segment_Missed == '' or Speaker_Error =='' or Noise_Labelling == ''or I_Capitalization =='' or ProperNoun_Capitalization == '' or Simple_Word_Error == '' or Referencing_Error == ''  or Punctuation_Error == '':
              return render_template('index.html', message='Please enter required fields')
        
        if db.session.query(Feedback).filter(Feedback.id == id):
            data = Feedback(date,time,Verifier_ID ,Audio_Length,Buffer_Space,Segment_Duplication,Segment_Missed,Speaker_Error,Noise_Labelling,I_Capitalization,ProperNoun_Capitalization,Simple_Word_Error, Referencing_Error,Punctuation_Error,Comments)
            db.session.add(data)
            db.session.commit()
            return render_template('submit.html')
          
    # return render_template('submit.html', 'thank you for the feedback')
    


if __name__ == '__main__':
    app.debug=True
    app.run()