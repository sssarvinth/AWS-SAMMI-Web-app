# -*- coding: utf-8 -*-
"""
Created on Mon Jun 29 19:56:22 2020

@author: Arvinth
"""

from flask import Flask, render_template,request
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)

ENV = 'prod'

if ENV == 'dev':
    app.debug = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost/awsfeedback'
else:
    app.debug = False
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgres://egndkyjieymiuu:6bb9180225be3ebf7e5e1692e0c7fbee81fd7eeb8682ba26bb254b0b10c09950@ec2-52-207-124-89.compute-1.amazonaws.com:5432/d2lnhqiah1sfhc'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


class Feedback(db.Model):
    __tablename__ = 'awsstranstracker'
    id = db.Column(db.Integer, primary_key=True)
    date=db.Column(db.Text())
    time=db.Column(db.Text())
    Transcriber_ID = db.Column(db.String(20))
    Audio_Length = db.Column(db.Text())
    

    def __init__(self,date,time,Transcriber_ID,Audio_Length):
        self.date=date
        self.time=time
        self.Transcriber_ID = Transcriber_ID
        self.Audio_Length = Audio_Length
        


@app.route('/')
def index():
    return render_template('transcription.html')


@app.route('/submit', methods=['POST'])
def submit():
      
    if request.method == 'POST':
        date= request.form['date']
        time= request.form['time']
        Transcriber_ID = request.form['Transcriber_ID']
  
        Audio_Length = request.form['Audio_Length']
       
        # print(user_id,segmentation_errorlist)
        
        if date =='' or Transcriber_ID == '' or Audio_Length =='':
              return render_template('index.html', message='Please enter required fields')
        
        if db.session.query(Feedback).filter(Feedback.id == id):
            data = Feedback(date,time,Transcriber_ID,Audio_Length)
            db.session.add(data)
            db.session.commit()
            return render_template('submit.html')
          
    # return render_template('submit.html', 'thank you for the feedback')
    


if __name__ == '__main__':
    app.debug=True
    app.run()